import spacy

def split_sentences_and_tokens(sentence):
    # Load the spaCy English model
    nlp = spacy.load("en_core_web_sm")

    # Tokenize the sentence
    doc = nlp(sentence)

    # Initialize variables
    sentences = []
    current_sentence = []

    # Iterate through tokens
    for token in doc:
        current_sentence.append(token.text)

        # Check for conditions to end the current sentence
        if token.text.lower() == 'and':
            if current_sentence:
                if len(current_sentence) > 1 and current_sentence[-2].isdigit() and current_sentence[-1].isdigit():
                    # Skip splitting if "and" is between two numbers
                    continue
                elif len(current_sentence) > 1 and doc[token.i + 1].pos_ == 'ADV':
                    # Split before "and" if it is followed by an adverb
                    sentences.append(' '.join(current_sentence[:-1]))
                    current_sentence = [current_sentence[-1]]
        elif token.text == ',':
            sentences.append(' '.join(current_sentence))
            current_sentence = []

    # Add the last sentence if any
    if current_sentence:
        sentences.append(' '.join(current_sentence))

    return sentences

def split_paragraph(paragraph):
    # Split paragraph into sentences based on full stops
    sentences = paragraph.split('. ')
    
    # Join sentences that end with digits to handle cases like "2.5 ms"
    cleaned_sentences = []
    current_sentence = ""
    for sent in sentences:
        if sent[-1].isdigit():
            current_sentence += sent
        else:
            if current_sentence:
                cleaned_sentences.append(current_sentence)
            current_sentence = sent
    
    if current_sentence:
        cleaned_sentences.append(current_sentence)

    return cleaned_sentences

# Provided paragraph
paragraph = '''

We've got a circuit with a 220-ohm resistor in series with a 10-microfarad capacitor, connected to a 12-volt voltage source. Find the time constant of this RC circuit. Once we have that, let's take it a step further. Imagine we introduce a switch in parallel to the capacitor and resistor. If the switch is initially open and then closed at time t = 0, I'm trying to figure out how long it takes for the voltage across the capacitor to reach about 63.2% of its maximum value.

A magnetic field cuts across a coil having 2,000 turns at the rate of 1,000 Wb/s. Calculate the induced voltage.

A magnetic field cuts across a coil having 250 turns at the rate of 0.04 Wb/s. Calculate the induced voltage.

A magnetic flux of 150 Mx cuts across a coil of 12,000 turns in 1 ms. Calculate the induced voltage.
A coil of 1,800 turns has an induced voltage of 150 V. Calculate the rate of flux change dydt in Wb/s.
The magnetic flux of a coil changes from 10,000 Wb to 4,000 Wb in 2.5 ms. How much is dydt?
The magnetic flux of a coil changes from 1,000 Mx to 16,000 Mx in 4 s. If the coil has 200 turns, what is the amount of induced voltage?
The magnetic flux around a coil is 80 Wb. If the coil has 50,000 turns, what is the amount of induced voltage when the flux remains stationary?
8. A coil has 120-V induced voltage when the rate of flux change is 0.4 Wb/s. How many turns are in the coil?
'''

# Split paragraph into sentences
sentences = split_paragraph(paragraph)

# Split and display sentences
for idx, sentence in enumerate(sentences, start=1):
    result = split_sentences_and_tokens(sentence)
    for i, split_sentence in enumerate(result, start=1):
        print(f"Sentence {idx}.{i}: {split_sentence}")
    print()
