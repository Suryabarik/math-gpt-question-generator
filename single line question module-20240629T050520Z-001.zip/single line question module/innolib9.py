import warnings
from sklearn.exceptions import DataConversionWarning

# Suppress the warning
warnings.filterwarnings("ignore", category=DataConversionWarning)

import pandas as pd    
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.svm import LinearSVC
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import accuracy_score
from sklearn.model_selection import GridSearchCV

# Load data from an Excel file
excel_file = 'C:\\Users\\HP\\Desktop\\innoLibreary\\innolib\\nlpDataset.xlsx'
df = pd.read_excel(excel_file)

# Handle missing values if necessary
df = df.dropna()

# Text preprocessing (add more steps if needed)
df['QUESTIONS'] = df['QUESTIONS'].apply(lambda x: x.lower())
df['QUESTIONS'] = df['QUESTIONS'].str.replace('[^\w\s]', '')

# Assuming your Excel file has 'Questions' and 'Answers' columns
questions = df['QUESTIONS'].tolist()
answers = df['ANSWERS'].tolist()

# Split the data into training and testing sets
train_questions, test_questions, train_answers, test_answers = train_test_split(questions, answers, test_size=0.2, random_state=45)

# Create TF-IDF vectorizer with custom parameters
vectorizer = TfidfVectorizer(max_features=5000, stop_words='english', ngram_range=(1, 2))

# Transform the training and testing data
X_train = vectorizer.fit_transform(train_questions)
X_test = vectorizer.transform(test_questions)

# Define the hyperparameter grid
param_grid = {
    'C': [0.1, 1, 10],
}

# Perform grid search with stratified cross-validation
grid_search = GridSearchCV(LinearSVC(), param_grid, cv=StratifiedKFold(n_splits=5))
grid_search.fit(X_train, train_answers)

# Get the best hyperparameters
best_params = grid_search.best_params_

# Train the model with the best hyperparameters
best_classifier = LinearSVC(**best_params)
best_classifier.fit(X_train, train_answers)

# Predict on the test set
best_predictions = best_classifier.predict(X_test)

# Calculate accuracy
best_accuracy = accuracy_score(test_answers, best_predictions)
print(f"Best Accuracy: {best_accuracy * 100:.2f}%")

# Interactive loop
while True:
    user_input = input("Enter multiple questions separated by commas (or type 'exit' to quit): ")
    if user_input.lower() == 'exit':
        break

    # Split the user's input into individual questions
    user_questions = [q.strip().lower().replace('[^\w\s]', '') for q in user_input.split(',')]

    # Transform each user question and predict the answer
    user_question_vectors = vectorizer.transform(user_questions)
    predicted_answers = best_classifier.predict(user_question_vectors)

    # Print the predicted answers for each question
    for question, answer in zip(user_questions, predicted_answers):
        print(f"Question: {question}, Predicted Answer: {answer}")
